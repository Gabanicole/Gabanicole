<?php
$host="localhost";
$username="root";
$password="";
$dbname="toon";
$conn = mysqli_connect($host,$username,$password,$dbname);
if($conn){
  echo "connected";
}
else{
  echo "failed".mysqli_error($conn);
}
?>