<!DOCTYPE html>
  <head>
 
 <title>TOON</title>
 <link rel="stylesheet" href="home.css">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <style>
	* {
	  box-sizing: border-box;
	}
	
	body {
	  margin: 0;
	  font-family: Arial;
	}
	
	/* The grid: Four equal columns that floats next to each other */
	.column {
	  float: left;
	  width: 25%;
	  padding: 10px;
	}
	
	/* Style the images inside the grid */
	.column img {
	  opacity: 0.8; 
	  cursor: pointer;   
	  background-color: rgb(144, 247, 247);
	}
	
	.column img:hover {
	  opacity: 1;
	}
	
	/* Clear floats after the columns */
	.row:after {
	  content: "";
	  display: table;
	  clear: both;
	
	}
	
	/* The expanding image container */
	.container {
	  position: relative;
	  display: none;
	}
	
	/* Expanding image text */
	#imgtext {
	  position: absolute;
	  bottom: 15px;
	  left: 15px;
	  color: white;
	  font-size: 20px;
	}
	
	/* Closable button inside the expanded image */
	.closebtn {
	  position: absolute;
	  top: 10px;
	  right: 15px;
	  color: white;
	  font-size: 35px;
	  cursor: pointer;
	}
	p.ex1 {
    border: px; 
    padding-bottom: 2em;
    text-align: center;
    background-color:rgb(177, 216, 248);
    
  }
	</style>
	
</head>

<body>

 <div class="header"><span>TOON</span></div>
   
   <div class="navbar">
	 <a href="home.php">Home</a>
	<a href="login.php">COMIC</a>
	<a href="login.php">LOGIN</a>
  </div>
  <!-- The four columns -->
  <div class="row">
	<div class="column">
	  <img src="illegal_0.jpg" alt="Education" style="width:100%" onclick="myFunction(this);">
	</div>
	<div class="column">
	  <img src="bunny_vs_monkey.jpg" alt="technology" style="width:100%" onclick="myFunction(this);">
	</div>
	<div class="column">
		 <img src="el_deafo.jpg" alt="adventure" style="width:100%">
   
	</div>
	<div class="column">
	  <img src="hilda_and_the_troll.jpg" alt="literature" style="width:100%" onclick="myFunction(this);">
	</div>
	</div>
</div>
<div class="row">
<div class="column">
	  <img src="nightlights.jpg" alt="Education" style="width:100%" onclick="myFunction(this);">
	</div>
	<div class="column">
	  <img src="lost_tales.jpg" alt="technology" style="width:100%" onclick="myFunction(this);">
	</div>
	<div class="column">
		 <img src="the-last-bear.jpg" alt="adventure" style="width:100%">
         
	</div>
	<div class="column">
	  <img src="mike-mouse.jpg" alt="literature" style="width:100%" onclick="myFunction(this);">
	</div>


</div>

  
  

  <p class="ex1">
	  @ 2020-2021 COPYRIGHT TOON LIBRARY
	  </p>

 </body>
</html>
